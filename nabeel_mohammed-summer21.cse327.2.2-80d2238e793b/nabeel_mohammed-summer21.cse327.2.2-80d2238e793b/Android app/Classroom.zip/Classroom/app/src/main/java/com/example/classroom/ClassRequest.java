package com.example.classroom;

public class ClassRequest {
private int teacher_id;


    public int getTeacher_id() {
        return teacher_id;
    }

    public void setTeacher_id(int teacher_id) {
        this.teacher_id = teacher_id;
    }
}
